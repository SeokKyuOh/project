package com.ss.driver;

public class Duck{
	private String name = "�� ����";
	public String getName(){
		return name;
	}

}
