package com.ss.driver;

public class MiracleDriver{
	private String name = "�� ����̹�";
	
	public String getName(){
		return name;
	}
}
