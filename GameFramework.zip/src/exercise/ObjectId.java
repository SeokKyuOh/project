package exercise;

public enum ObjectId {
	Player, Enemey, Block, Bullet, Item
}
