package test;
import com.ss.driver.MiracleDriver;

class UseDriver{
	public static void main(String[] args){
		MiracleDriver md = new MiracleDriver();
		System.out.println(md.getName());
	}

}
